# 语音对讲主板 V5：UPS稳压5V方案

本版按用户确认的“UPS输出稳压5V”设计后级主板，保留100×75mm双层、单面SMT、ESP32-S3 N8R8和ML307C-DL贴板。官方ESP WebRTC协议、MQTT/WS信令和实时主动丢旧包代码未改。V4保留为上一版完整分立电源的设计基线。

**UPS内部电路尚未选型。** `U15`是电气接口及40×18mm预留区域，六个焊线孔不是猜测的充电芯片封装。需要用户的5元UPS板到货、识别芯片与参数后，才能补齐内部充电、切换、欠压和升压电路。当前文件用于审阅与后级主板设计，不是最终生产放行文件。

## 原生工程与预览

- [可编辑PCB](voice_mainboard_v5.kicad_pcb)
- [可编辑原理图](voice_mainboard_v5.kicad_sch)
- [KiCad工程](voice_mainboard_v5.kicad_pro)
- [预览页](exports/review.html)，本机服务入口`http://127.0.0.1:18897/`
- [最新检查记录](exports/validation.json)
- [当前位号BOM与预算](cost/bom-budget.json)

## 供电连接

`圆口5V → 保险丝/反接保护 → UPS输入`；`受保护1S电池 → UPS`。

UPS稳压5V输出分成三路：

1. TPS563201降压约3.779V，给ML307C-DL供电。
2. SY8089A1降压约3.315V，给ESP32-S3和外接麦克风模块供电。
3. 直接5V给I2S功放和可选雷达接口。

4G降压器移到模组供电脚附近，采用TI DDC0006A推荐焊盘，39.2k/10k反馈。470μF储能电容放在5V侧，3.8V输出侧采用2×22μF＋10μF，避免直接把原约500μF负载放入新降压闭环。SY8089反馈使用应用表100k/22.1k，增加22pF前馈电容。电感额定电流、电容直流偏压后的有效容量及实际负载仍需验收。

UPS接口从原板对照位号`U15`读：1输入保护后5V、2地、3稳压输出5V、4地、5受保护电池正极/采样、6地。它是本设计的焊线测试接口，**不能按此针序直接套接任意商家的UPS模块**。5V输入到输出没有未经稳压的旁路。

## 保留的接口

| 接口 | 定义 |
|---|---|
| J1 | 5.5/2.5mm圆口，中心正极；5V/2A适配器基线 |
| J18 TTL | GND、ESP TX43、ESP RX44、适配器5V；逻辑3.3V，主电源供电时TTL的5V线不接 |
| J16可选雷达 | 5V、GND、ESP RX6、ESP TX8；R58默认不贴 |
| J17外部呼叫按钮 | BOOT GPIO0、GND；板上BOOT键保留 |
| J14麦克风 | 外接INMP441模块接口；模块不计主板预算 |
| J15喇叭 | 功放BTL＋/−，任一端均不能接地 |
| 电池采样 | GPIO2 ADC、GPIO9采样开关，名义电压比例2.5 |
| 外电检测 | GPIO10检测适配器掉电；UPS切换不依赖这个GPIO |
| USB预留 | 维修/ESP Host采用互斥0Ω选装；当前固件USB通话尚未验证 |

## 成本与待定器件

ML30710元、ESP12元、UPS整组5元沿用用户采购预算。已落实SRV05-4四路SIM保护、SY8089及TPS563201。廉价SHOU HAN SIM座缺精确机械/焊盘图，本版保留已存在的JAE SF72S006封装及2.51元预算，后续拿到图纸才能替换。

当前板上已定零件＋UPS5元额度约44.09元，加既有PCB/贴装/损耗/测试8.50元预算，约**52.59元/台**。SIM换成0.6096元候选后，条件预算约**50.69元/台**。这些是预算，不是嘉立创整单报价；UPS5元额度不证明芯片、保护或2A负载能力已确认。电池/NTC、充电器、外壳、喇叭、麦克风模块、雷达及线束不计。详见自动生成的[费用说明](cost/费用说明.md)。

## 检查边界

原理图ERC、PCB DRC和未连接数以最新`exports/validation.json`为准。位号、DNP、引脚、电压分压方程及C-DL109焊盘另外核查。连接检查不能证明启动、切换、温升或通话稳定性。

2026-11-22本版最终保存文件：**ERC 0、DRC 0、未连接0**。原理图XML与PCB的337个已连接引脚逐项相符，84个明确不接的引脚另外核查；C-DL109焊盘及TPS563201厂家推荐焊盘核对通过。21组未重做的主电源/开关回路铜线按UUID核对仍在；ESP反馈和供电分支已重新布线并纳入最终连接检查。板上默认不贴项已与原理图、BOM同步，包括USB Host选装电阻、雷达供电跳线和射频匹配预留件。

TI官方PSpice瞬态模型已在当前ngspice兼容环境尝试，出现收敛错误，**没有记为仿真通过**；网表、日志和[结果](exports/modem-buck-model/result.json)保留。这不是UPS或整机仿真，不能据此确认2A瞬态电压。需要兼容仿真器或新板实测补足。

打样前还需：UPS内部电路和确切封装、SIM座尺寸、新C-DL硬件手册与实物、电源启动/瞬态/热/掉电上报、RF/USB阻抗与天线、厂家DFM和钢网、整机长通话。

模组库来源：**嘉立创EDA/EasyEDA官方库 / JLCEDA/EasyEDA Official Library**，主页[嘉立创EDA](https://lceda.cn/)、[EasyEDA](https://easyeda.com/)。来源、原始库SHA256与焊盘数据保存于`sources/ml307c-dl-library.json`。TI降压焊盘另按厂家DDC0006A图纸转录，见`sources/tps563201-land.json`。

## 重建

`generate_design.py`会从V4复制器件布局、替换电源电路并清空布线。随后运行`route_power.py`、`fill_planes.py`、原生DRC、`prepare_route.py`导出DSN；Freerouting后用`import_route.py`导入并补齐原生检查报告的连接；生成原理图、绑定ID、放置丝印后重新ERC/DRC，最后`build_review.py`生成预览和成本。不要在最终PCB上直接运行生成器，否则会重置布线。

布线辅助脚本包含局部调整过程，交付基准是最终原生CAD文件和绑定其SHA256的检查记录。旧试线报告保留在本机`build/v5-reference/archived-route-reports/`，不作为最终验收报告。下载ZIP包含CAD、库、BOM与检查说明，不包含投产Gerber/钻孔文件。
